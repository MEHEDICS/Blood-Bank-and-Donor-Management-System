<?php
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>Blood Bank Donor Management System | Home Page</title>
	
	<script>
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>

	<!-- Custom-Files -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
	<link rel="stylesheet" href="css/fontawesome-all.css">
	<!-- Web-Fonts -->
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese"
	    rel="stylesheet">
</head>

<body>
	<?php include('includes/header.php');?>

	<!-- banner -->
	<div class="slider">
		<div class="callbacks_container">
			<ul class="rslides callbacks callbacks1" id="slider4">
				<li>
					<div class="banner-top1">
						<div class="banner-info_agile_w3ls">
							<div class="container">
								<h3>Blood bank services that you <span>can trust</span></h3>
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="banner-top2">
						<div class="banner-info_agile_w3ls">
							<div class="container">
								<h3>One Blood Donation Saves three Lives <span>every day</span></h3>
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="banner-top3">
						<div class="banner-info_agile_w3ls">
							<div class="container">
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
	</div>
	<div class="clearfix"></div>

	<!-- Add Button for Rare Blood Groups -->
	<div class="text-center my-4">
	    <button type="button" class="btn btn-danger btn-lg" data-toggle="modal" data-target="#rareBloodModal">
	        Rare Blood Groups
	    </button>
	</div>

<!-- Rare Blood Groups Modal -->
<div class="modal fade" id="rareBloodModal" tabindex="-1" role="dialog" aria-labelledby="rareBloodModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="border-radius: 15px;">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title font-weight-bold" id="rareBloodModalLabel">Rare Blood Groups</h5>
                <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body text-dark p-4">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>🩸 Rh-null:</strong> "Golden Blood" – less than 50 people worldwide.</li>
                    <li class="list-group-item"><strong>🩸 AB-negative:</strong> Found in less than 1% of the population.</li>
                    <li class="list-group-item"><strong>🩸 B-negative:</strong> Very rare in many regions.</li>
                    <li class="list-group-item"><strong>🩸 Bombay Blood Group:</strong> Found mainly in India, rare globally.</li>
                    <li class="list-group-item"><strong>🩸 A-negative:</strong> Rare in some populations.</li>
                </ul>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" style="border-radius: 20px;">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Blood Donation Quotes Section -->
<div class="quotes-section py-5 bg-light">
    <div class="container">
        <div class="text-center mb-4">
            <h2 class="text-danger font-weight-bold">Inspiring Words on Blood Donation</h2>
            <p class="text-muted">Every drop counts. Give blood, save lives!</p>
        </div>

        <div id="quoteCarousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner text-center">
                <div class="carousel-item active">
                    <div class="card shadow-sm p-4" style="border-radius: 15px;">
                        <p class="lead font-italic">"We cannot live only for ourselves. A thousand fibers connect us with our fellow men."</p>
                        <h5 class="text-danger font-weight-bold mt-3">- Herman Melville</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card shadow-sm p-4" style="border-radius: 15px;">
                        <p class="lead font-italic">"To the young and healthy, it's no loss. To the sick, it's hope of life. Donate Blood to give back life."</p>
                        <h5 class="text-danger font-weight-bold mt-3">- Mother Teresa</h5>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="card shadow-sm p-4" style="border-radius: 15px;">
                        <p class="lead font-italic">"The simplest acts of kindness are by far more powerful than a thousand heads bowing in prayer."</p>
                        <h5 class="text-danger font-weight-bold mt-3">- Mahatma Gandhi</h5>
                    </div>
                </div>
            </div>
            
            <!-- Carousel Controls -->
            <a class="carousel-control-prev" href="#quoteCarousel" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon bg-danger rounded-circle p-3" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#quoteCarousel" role="button" data-slide="next">
                <span class="carousel-control-next-icon bg-danger rounded-circle p-3" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
</div>



	<!-- blog -->
	<div class="blog-w3ls py-5" id="blog">
		<div class="container py-xl-5 py-lg-3">
			<div class="w3ls-titles text-center mb-5">
				<h3 class="title text-white">Some of the Donors</h3>
				<span><i class="fas fa-user-md text-white"></i></span>
			</div>
			<div class="row package-grids mt-5">
				<?php 
$status=1;
$sql = "SELECT * from tblblooddonars where status=:status order by rand() limit 6";
$query = $dbh -> prepare($sql);
$query->bindParam(':status',$status,PDO::PARAM_STR);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
if($query->rowCount() > 0)
{
foreach($results as $result)
{ ?>
<div class="col-md-4 pricing" style="margin-top:2%;">
    <div class="card shadow-sm rounded">
        <div class="price-top text-center p-3">
            <?php 
            $profileImage = (!empty($result->profile_image)) ? 'uploads/' . $result->profile_image : 'images/blood-donor.jpg'; 
            ?>
            <img src="<?php echo $profileImage; ?>" alt="Blood Donor" 
                 style="border: 5px solid red; border-radius: 50%; width: 120px; height: 120px;" 
                 class="img-fluid mb-3" />
        </div>
        <div class="text-center mb-2">
            <h5 class="text-dark font-weight-bold"><?php echo htmlentities($result->FullName); ?></h5>
        </div>
        <div class="price-bottom p-4 text-center">
            <h4 class="text-dark mb-3">Gender: <?php echo htmlentities($result->Gender);?></h4>
            <p class="card-text mb-3"><b>Blood Group:</b> <?php echo htmlentities($result->BloodGroup);?></p>
            <a class="btn btn-primary" style="color:#fff; border-radius: 20px; padding: 10px 20px;" 
               href="contact-blood.php?cid=<?php echo $result->id;?>">Request</a>
        </div>
    </div>
</div>
<?php }} ?>
			</div>
		</div>
	</div>

	<!-- footer -->
	<?php include('includes/footer.php');?>

	<!-- Js files -->
	<script src="js/jquery-2.2.3.min.js"></script>
	<script src="js/responsiveslides.min.js"></script>
	<script>
		$(function () {
			$("#slider4").responsiveSlides({
				auto: true,
				pager: true,
				nav: true,
				speed: 1000,
				namespace: "callbacks"
			});
		});
	</script>
	<script src="js/bootstrap.js"></script>

</body>
</html>
