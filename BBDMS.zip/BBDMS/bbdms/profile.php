<?php 
session_start();
error_reporting(0);
include('includes/config.php');

if (strlen($_SESSION['bbdmsdid'] == 0)) {
    header('location:logout.php');
} else {

    if (isset($_POST['update'])) {
        $uid = $_SESSION['bbdmsdid'];
        $name = $_POST['fullname'];
        $mno = $_POST['mobileno'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $bloodgroup = $_POST['bloodgroup'];
        $address = $_POST['address'];
        $message = $_POST['message'];

        // Handle profile image update
        $profileImage = '';
        $sql = "SELECT profile_image FROM tblblooddonars WHERE id=:uid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':uid', $uid, PDO::PARAM_STR);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_OBJ);
        if ($result) {
            $profileImage = $result->profile_image;
        }

        if (!empty($_FILES['profile_image']['name'])) {
            $targetDir = "uploads/";
            $fileName = time() . "_" . basename($_FILES['profile_image']['name']);
            $targetFilePath = $targetDir . $fileName;
            $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

            // Validate file type
            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array($fileType, $allowedTypes)) {
                if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFilePath)) {
                    $profileImage = $fileName; // Update profile image filename
                } else {
                    echo '<script>alert("Failed to upload the new profile image. Please try again.");</script>';
                }
            } else {
                echo '<script>alert("Invalid file format. Only JPG, JPEG, PNG, and GIF files are allowed.");</script>';
            }
        }

        $sql = "UPDATE tblblooddonars SET FullName=:name, MobileNumber=:mno, Age=:age, Gender=:gender, BloodGroup=:bloodgroup, Address=:address, Message=:message, profile_image=:profile_image WHERE id=:uid";
        $query = $dbh->prepare($sql);
        $query->bindParam(':name', $name, PDO::PARAM_STR);
        $query->bindParam(':mno', $mno, PDO::PARAM_STR);
        $query->bindParam(':age', $age, PDO::PARAM_STR);
        $query->bindParam(':gender', $gender, PDO::PARAM_STR);
        $query->bindParam(':bloodgroup', $bloodgroup, PDO::PARAM_STR);
        $query->bindParam(':address', $address, PDO::PARAM_STR);
        $query->bindParam(':message', $message, PDO::PARAM_STR);
        $query->bindParam(':profile_image', $profileImage, PDO::PARAM_STR);
        $query->bindParam(':uid', $uid, PDO::PARAM_STR);
        $query->execute();

        echo '<script>alert("Profile has been updated successfully.");</script>';
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Blood Bank Donor Management System - Donor Profile</title>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link href="//fonts.googleapis.com/css?family=Open+Sans|Roboto+Condensed" rel="stylesheet">
    <style>
        .profile-container {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 30px;
        }

        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 3px solid #007bff;
            object-fit: cover;
        }

        .profile-info {
            flex: 1;
        }

        .profile-info h4 {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .profile-info p {
            margin: 5px 0;
        }

        .profile-section, .update-section {
            flex: 1;
            padding: 20px;
        }

        .form-group label {
            font-weight: bold;
        }

        .main-container {
            display: flex;
            gap: 30px;
        }

        .update-section {
            border-left: 1px solid #ddd;
        }
    </style>
</head>

<body>
    <?php include('includes/header.php'); ?>

    <div class="inner-banner-w3ls">
        <div class="container"></div>
    </div>

    <div class="breadcrumb-agile">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Donor Profile</li>
            </ol>
        </div>
    </div>

    <div class="appointment py-5">
        <div class="py-xl-5 py-lg-3">
            <div class="w3ls-titles text-center mb-5">
                <h3 class="title">Donor Profile</h3>
                <span><i class="fas fa-user-md"></i></span>
            </div>
            <div class="main-container">
                <div class="profile-section">
                    <h5 class="title-w3 mb-4">Your Profile</h5>
                    <?php
                    $uid = $_SESSION['bbdmsdid'];
                    $sql = "SELECT * FROM tblblooddonars WHERE id=:uid";
                    $query = $dbh->prepare($sql);
                    $query->bindParam(':uid', $uid, PDO::PARAM_STR);
                    $query->execute();
                    $results = $query->fetchAll(PDO::FETCH_OBJ);
                    if ($query->rowCount() > 0) {
                        foreach ($results as $row) {
                            $profileImage = $row->profile_image;
                            $imagePath = !empty($profileImage) ? "uploads/" . $profileImage : "images/default-profile.png";
                    ?>
                            <div class="profile-container">
                                <img src="<?php echo $imagePath; ?>" alt="Profile Picture" class="profile-image">
                                <div class="profile-info">
                                    <h4><?php echo $row->FullName; ?></h4>
                                    <p><strong>Blood Group:</strong> <?php echo $row->BloodGroup; ?></p>
                                    <p><strong>Mobile:</strong> <?php echo $row->MobileNumber; ?></p>
                                    <p><strong>Email:</strong> <?php echo $row->EmailId; ?></p>
                                    <p><strong>Age:</strong> <?php echo $row->Age; ?></p>
                                    <p><strong>Gender:</strong> <?php echo $row->Gender; ?></p>
                                    <p><strong>Address:</strong> <?php echo $row->Address; ?></p>
                                    <p><strong>Message:</strong> <?php echo $row->Message; ?></p>
                                </div>
                            </div>
                    <?php
                        }
                    }
                    ?>
                </div>

                <div class="update-section">
                    <h5 class="title-w3 mb-4">Update Your Profile</h5>
                    <form action="#" method="post" enctype="multipart/form-data">
                        <?php if ($query->rowCount() > 0) { ?>
                            <div class="form-group">
                                <label for="fullname">Full Name</label>
                                <input type="text" class="form-control" name="fullname" value="<?php echo $row->FullName; ?>">
                            </div>
                            <div class="form-group">
                                <label for="mobileno">Mobile Number</label>
                                <input type="text" class="form-control" name="mobileno" value="<?php echo $row->MobileNumber; ?>" required maxlength="10" pattern="[0-9]+">
                            </div>
                            <div class="form-group">
                                <label for="emailid">Email Id</label>
                                <input type="email" name="emailid" class="form-control" value="<?php echo $row->EmailId; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="age">Age</label>
                                <input type="text" class="form-control" name="age" value="<?php echo $row->Age; ?>">
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select name="gender" class="form-control">
                                    <option value="<?php echo $row->Gender; ?>"><?php echo $row->Gender; ?></option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="bloodgroup">Blood Group</label>
                                <select name="bloodgroup" class="form-control">
                                    <option value="<?php echo $row->BloodGroup; ?>"><?php echo $row->BloodGroup; ?></option>
                                    <?php
                                    $sql = "SELECT * FROM tblbloodgroup";
                                    $query = $dbh->prepare($sql);
                                    $query->execute();
                                    $groups = $query->fetchAll(PDO::FETCH_OBJ);
                                    foreach ($groups as $group) {
                                    ?>
                                        <option value="<?php echo $group->BloodGroup; ?>"><?php echo $group->BloodGroup; ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" name="address" value="<?php echo $row->Address; ?>">
                            </div>
                            <div class="form-group">
                                <label for="message">Message</label>
                                <textarea class="form-control" name="message"><?php echo $row->Message; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="profile_image">Update Profile Picture</label>
                                <input type="file" name="profile_image" class="form-control" accept="image/*">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary" name="update">Update Profile</button>
                            </div>
                        <?php } ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include('includes/footer.php'); ?>
</body>

</html>
>

<?php } ?>
