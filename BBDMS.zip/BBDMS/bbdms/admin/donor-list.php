<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {    
    header('location:index.php');
} else {
    if(isset($_REQUEST['hidden'])) {
        $eid=intval($_GET['hidden']);
        $status="0";
        $sql = "UPDATE tblblooddonars SET Status=:status WHERE  id=:eid";
        $query = $dbh->prepare($sql);
        $query -> bindParam(':status',$status, PDO::PARAM_STR);
        $query-> bindParam(':eid',$eid, PDO::PARAM_STR);
        $query -> execute();

        $msg="Donor details hidden Successfully";
    }

    if(isset($_REQUEST['public'])) {
        $aeid=intval($_GET['public']);
        $status=1;

        $sql = "UPDATE tblblooddonars SET Status=:status WHERE  id=:aeid";
        $query = $dbh->prepare($sql);
        $query -> bindParam(':status',$status, PDO::PARAM_STR);
        $query-> bindParam(':aeid',$aeid, PDO::PARAM_STR);
        $query -> execute();

        $msg="Donor details public";
    }

    // Code for Deletion
    if(isset($_REQUEST['del'])) {
        $did=intval($_GET['del']);
        $sql = "DELETE from tblblooddonars WHERE  id=:did";
        $query = $dbh->prepare($sql);
        $query-> bindParam(':did',$did, PDO::PARAM_STR);
        $query -> execute();

        $msg="Record deleted Successfully ";
    }
?>

<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Donor List</title>

    <!-- Font awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="css/style.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS for Gorgeous UI -->
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f4f7fc;
        }

        .page-title {
            font-size: 30px;
            font-weight: 600;
            color: #333;
            margin-bottom: 20px;
        }

        .panel {
            border-radius: 10px;
            transition: all 0.3s ease-in-out;
        }

        .panel:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transform: scale(1.03);
        }

        .panel-heading {
            background: linear-gradient(45deg, #1e3c72, #2a5298);
            color: #fff;
            padding: 15px;
            border-radius: 10px 10px 0 0;
            font-weight: bold;
        }

        .panel-body {
            padding: 20px;
            background-color: #fff;
            border-radius: 0 0 10px 10px;
        }

        .table thead {
            background: #f3f6fb;
            color: #333;
            font-weight: 600;
        }

        .btn-primary {
            background-color: #1e3c72;
            border-color: #1e3c72;
            font-weight: 500;
        }

        .btn-primary:hover {
            background-color: #2a5298;
            border-color: #2a5298;
        }

        .btn-danger {
            background-color: #f44336;
            border-color: #f44336;
            font-weight: 500;
        }

        .btn-danger:hover {
            background-color: #e53935;
            border-color: #e53935;
        }

        .errorWrap, .succWrap {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 10px;
            font-weight: 600;
        }

        .errorWrap {
            background: #f8d7da;
            border-left: 4px solid #dd3d36;
            color: #721c24;
        }

        .succWrap {
            background: #d4edda;
            border-left: 4px solid #28a745;
            color: #155724;
        }

        .panel-footer {
            text-align: center;
            font-weight: bold;
            background: #fff;
            padding: 10px;
            border-radius: 0 0 10px 10px;
        }

        .panel-footer a {
            color: #1e3c72;
            text-decoration: none;
            font-weight: 500;
        }

        .panel-footer a:hover {
            color: #2a5298;
        }
    </style>
</head>

<body>
    <?php include('includes/header.php'); ?>

    <div class="ts-main-content">
        <?php include('includes/leftbar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">

                        <h2 class="page-title">Donors List</h2>

                        <div class="panel panel-default">
                            <div class="panel-heading">Donors Info</div>
                            <a href="download-records.php" style="font-size:16px;" class="btn btn-info">Download Donor List</a>
                            <div class="panel-body">
                                <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
                                else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
                                
                                <table id="zctb" class="display table table-striped table-bordered table-hover" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Mobile No</th>
                                            <th>Email</th>
                                            <th>Age</th>
                                            <th>Gender</th>
                                            <th>Blood Group</th>
                                            <th>Address</th>
                                            <th>Message</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $sql = "SELECT * FROM tblblooddonars";
                                        $query = $dbh->prepare($sql);
                                        $query->execute();
                                        $results = $query->fetchAll(PDO::FETCH_OBJ);
                                        $cnt = 1;
                                        if($query->rowCount() > 0) {
                                            foreach($results as $result) { ?>
                                                <tr>
                                                    <td><?php echo htmlentities($cnt); ?></td>
                                                    <td><?php echo htmlentities($result->FullName); ?></td>
                                                    <td><?php echo htmlentities($result->MobileNumber); ?></td>
                                                    <td><?php echo htmlentities($result->EmailId); ?></td>
                                                    <td><?php echo htmlentities($result->Age); ?></td>
                                                    <td><?php echo htmlentities($result->Gender); ?></td>
                                                    <td><?php echo htmlentities($result->BloodGroup); ?></td>
                                                    <td><?php echo htmlentities($result->Address); ?></td>
                                                    <td><?php echo htmlentities($result->Message); ?></td>
                                                    <td>
                                                        <?php if($result->status == 1) { ?>
                                                            <a href="donor-list.php?hidden=<?php echo htmlentities($result->id); ?>" onclick="return confirm('Do you really want to hide this detail?')" class="btn btn-primary">Make it Hidden</a>
                                                        <?php } else { ?>
                                                            <a href="donor-list.php?public=<?php echo htmlentities($result->id); ?>" onclick="return confirm('Do you really want to public this detail?')" class="btn btn-primary">Make it Public</a>
                                                        <?php } ?>
                                                        <a href="donor-list.php?del=<?php echo htmlentities($result->id); ?>" onclick="return confirm('Do you really want to delete this record?')" class="btn btn-danger" style="margin-top:1%;">Delete</a>
                                                    </td>
                                                </tr>
                                            <?php $cnt++; }
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Loading Scripts -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>

<?php } ?>
