<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0) {    
    header('location:index.php');
} else {
?>
<!doctype html>
<html lang="en" class="no-js">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="theme-color" content="#3e454c">

    <title>BBDMS | Admin Dashboard</title>

    <!-- Font awesome -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
    <!-- Custom Style -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Custom CSS for Gorgeous UI -->
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background: #f7f7f7;
            color: #333;
        }

        .page-title {
            font-size: 28px;
            font-weight: 500;
            margin-bottom: 20px;
            color: #333;
        }

        .panel {
            border-radius: 10px;
            margin-bottom: 20px;
            transition: all 0.3s ease-in-out;
        }

        .panel:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transform: scale(1.03);
        }

        .panel-body {
            padding: 20px;
            color: #fff;
            border-radius: 10px;
        }

        .panel .stat-panel {
            display: inline-block;
            width: 100%;
        }

        .stat-panel-number {
            font-size: 50px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .stat-panel-title {
            font-size: 18px;
            font-weight: 400;
        }

        .panel-footer {
            text-align: center;
            font-weight: 500;
            color: #333;
            background: #fff;
            border-top: 1px solid #ddd;
            padding: 10px;
            border-radius: 0 0 10px 10px;
            text-decoration: none;
        }

        .panel-footer:hover {
            background-color: #f4f4f4;
        }

        .bk-primary {
            background: linear-gradient(135deg, #1e3c72, #2a5298);
        }

        .bk-success {
            background: linear-gradient(135deg, #56ab2f, #a8e063);
        }

        .bk-info {
            background: linear-gradient(135deg, #00c6ff, #0072ff);
        }

        .bk-danger {
            background: linear-gradient(135deg, #ff416c, #ff4b2b);
        }
    </style>
</head>

<body>
    <?php include('includes/header.php'); ?>

    <div class="ts-main-content">
        <?php include('includes/leftbar.php'); ?>
        <div class="content-wrapper">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-md-12">
                        <h2 class="page-title">Dashboard</h2>

                        <div class="row">
                            <!-- Listed Blood Groups -->
                            <div class="col-md-3">
                                <div class="panel panel-default">
                                    <div class="panel-body bk-primary text-light">
                                        <div class="stat-panel text-center">
                                            <?php 
                                            $sql = "SELECT id FROM tblbloodgroup";
                                            $query = $dbh->prepare($sql);
                                            $query->execute();
                                            $bg = $query->rowCount();
                                            ?>
                                            <div class="stat-panel-number h1"><?php echo htmlentities($bg); ?></div>
                                            <div class="stat-panel-title text-uppercase">Listed Blood Groups</div>
                                        </div>
                                    </div>
                                    <a href="manage-bloodgroup.php" class="block-anchor panel-footer">Full Detail <i class="fa fa-arrow-right"></i></a>
                                </div>
                            </div>

                            <!-- Registered Blood Donors -->
                            <div class="col-md-3">
                                <div class="panel panel-default">
                                    <div class="panel-body bk-success text-light">
                                        <div class="stat-panel text-center">
                                            <?php 
                                            $sql1 = "SELECT id FROM tblblooddonars";
                                            $query1 = $dbh->prepare($sql1);
                                            $query1->execute();
                                            $regbd = $query1->rowCount();
                                            ?>
                                            <div class="stat-panel-number h1"><?php echo htmlentities($regbd); ?></div>
                                            <div class="stat-panel-title text-uppercase">Registered Blood Donors</div>
                                        </div>
                                    </div>
                                    <a href="donor-list.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
                                </div>
                            </div>

                            <!-- Total Queries -->
                            <div class="col-md-3">
                                <div class="panel panel-default">
                                    <div class="panel-body bk-info text-light">
                                        <div class="stat-panel text-center">
                                            <?php 
                                            $sql6 = "SELECT id FROM tblcontactusquery";
                                            $query6 = $dbh->prepare($sql6);
                                            $query6->execute();
                                            $queryCount = $query6->rowCount();
                                            ?>
                                            <div class="stat-panel-number h1"><?php echo htmlentities($queryCount); ?></div>
                                            <div class="stat-panel-title text-uppercase">Total Queries</div>
                                        </div>
                                    </div>
                                    <a href="manage-conactusquery.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
                                </div>
                            </div>

                            <!-- Total Blood Requests -->
                            <div class="col-md-3">
                                <div class="panel panel-default">
                                    <div class="panel-body bk-danger text-light">
                                        <div class="stat-panel text-center">
                                            <?php 
                                            $sql7 = "SELECT ID FROM tblbloodrequirer";
                                            $query7 = $dbh->prepare($sql7);
                                            $query7->execute();
                                            $totalRequests = $query7->rowCount();
                                            ?>
                                            <div class="stat-panel-number h1"><?php echo htmlentities($totalRequests); ?></div>
                                            <div class="stat-panel-title text-uppercase">Total Blood Requests</div>
                                        </div>
                                    </div>
                                    <a href="requests-received.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
                                </div>
                            </div>

                        </div> <!-- End row -->
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Loading Scripts -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.min.js"></script>
    <script src="js/dataTables.bootstrap.min.js"></script>

</body>
</html>
<?php } ?>
