<?php
error_reporting(0);
include('includes/config.php');
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Blood Donor List | Blood Bank</title>

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/fontawesome-all.css">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />

    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }
        .card {
            border-radius: 15px;
            transition: transform 0.3s, box-shadow 0.3s;
            border: none;
            background: white;
            padding: 20px;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
        }
        .profile-img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            border: 3px solid #dc3545;
        }
        .btn-custom {
            background: linear-gradient(45deg, #ff416c, #ff4b2b);
            color: white;
            border-radius: 25px;
            padding: 10px 20px;
            transition: 0.3s;
        }
        .btn-custom:hover {
            background: linear-gradient(45deg, #ff4b2b, #ff416c);
        }
    </style>
</head>


<body>
    <?php include('includes/header.php');?>

    <div class="inner-banner-w3ls">
        <div class="container"></div>
    </div>

    <div class="breadcrumb-agile">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Blood Donor List</li>
            </ol>
        </div>
    </div>

	<div class="container py-5">
        <h2 class="text-center text-danger mb-4">Blood Donor List</h2>
        <div class="row">
            <?php
            $status = 1;
            $sql = "SELECT * FROM tblblooddonars WHERE status=:status";
            $query = $dbh->prepare($sql);
            $query->bindParam(':status', $status, PDO::PARAM_STR);
            $query->execute();
            $results = $query->fetchAll(PDO::FETCH_OBJ);
            if ($query->rowCount() > 0) {
                foreach ($results as $result) { ?>
                    <div class="col-md-4 mb-4">
                        <div class="card p-3 text-center">
                            <img src="<?php echo (!empty($result->profile_image)) ? 'uploads/' . $result->profile_image : 'images/blood-donor.jpg'; ?>" 
                                class="profile-img mx-auto" alt="Blood Donor" />
                            <h5 class="mt-3 text-dark"> <?php echo htmlentities($result->FullName); ?> </h5>
                            <p class="text-muted">Blood Group: <strong class="text-danger"> <?php echo htmlentities($result->BloodGroup); ?></strong></p>
                            <table class="table table-borderless text-start">
                                <tr><td>Gender:</td><td><?php echo htmlentities($result->Gender);?></td></tr>
                                <tr><td>Age:</td><td><?php echo htmlentities($result->Age);?></td></tr>
                                <tr><td>Mobile:</td><td><?php echo htmlentities($result->MobileNumber);?></td></tr>
                                <tr><td>Last Donation:</td><td><?php echo !empty($result->LastDonateDate) ? htmlentities($result->LastDonateDate) : 'Not Available'; ?></td></tr>
                            </table>
                            <a href="contact-blood.php?cid=<?php echo $result->id;?>" class="btn btn-custom">Request Blood</a>
                        </div>
                    </div>
                <?php }
            } ?>
        </div>
    </div>

    <?php include('includes/footer.php');?>

    <script src="js/jquery-2.2.3.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>

    <script>
        $(function () {
            $("#slider4").responsiveSlides({
                auto: true,
                pager: true,
                nav: true,
                speed: 1000,
                namespace: "callbacks"
            });
        });
    </script>
    <script src="js/fixed-nav.js"></script>
    <script src="js/SmoothScroll.min.js"></script>
    <script src="js/move-top.js"></script>
    <script src="js/easing.js"></script>
    <script src="js/medic.js"></script>
    <script src="js/bootstrap.js"></script>

</body>

</html>


